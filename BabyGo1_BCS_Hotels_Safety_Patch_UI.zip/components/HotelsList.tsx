// components/HotelsList.tsx
export type HotelItemUI = {
  name: string;
  rating?: number | null;
  ratings?: number | null;
  priceLevel?: number | null;
  address?: string;
  maps_url?: string | null;
  hints?: { likelyCribs?: boolean };
  score?: number;
  grade?: "A"|"B"|"C"|"D";
};

export default function HotelsList({ items }:{ items: HotelItemUI[] }){
  if (!items || items.length === 0) return <p className="text-sm text-gray-600">No hotels found for this destination yet.</p>;
  return (
    <div className="grid gap-3 md:grid-cols-2">
      {items.map((h,i)=>(
        <div key={i} className="rounded-xl border p-3">
          <div className="flex items-center justify-between">
            <div className="font-medium">{h.name}</div>
            <div className="text-xs">
              {h.grade ? <span className="mr-2 rounded bg-indigo-50 px-2 py-0.5 text-indigo-700">BCS {h.grade}</span> : null}
              {h.rating != null ? <>⭐ {h.rating} ({h.ratings ?? 0})</> : null}
            </div>
          </div>
          {h.address ? <div className="text-xs text-gray-600">{h.address}</div> : null}
          <div className="mt-1 text-xs">
            {h.priceLevel != null ? `Price level: ${"$$$$".slice(0, Math.max(1, Math.min(4, Number(h.priceLevel))))}` : "Price level: —"}
            {h.hints?.likelyCribs ? " · Likely provides cribs" : ""}
            {typeof h.score === "number" ? ` · Score: ${h.score}` : ""}
          </div>
          {h.maps_url ? (
            <div className="mt-1">
              <a target="_blank" className="inline-block rounded bg-indigo-100 px-2 py-0.5 text-xs text-indigo-700 hover:bg-indigo-200" href={h.maps_url}>
                Open in Google Maps
              </a>
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}
