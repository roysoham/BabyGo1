// components/SafetyList.tsx
export type SafetyItem = {
  type: string;
  name: string;
  address?: string;
  rating?: number | null;
  maps_url?: string | null;
  phone?: string | null;
  open_now?: boolean | null;
};

export default function SafetyList({ items }:{ items: SafetyItem[] }){
  if (!items || items.length === 0) return <p className="text-sm text-gray-600">No clinics/pharmacies found yet.</p>;
  return (
    <div className="grid gap-3 md:grid-cols-2">
      {items.map((s,i)=>(
        <div key={i} className="rounded-xl border p-3">
          <div className="font-medium">{s.name}</div>
          {s.address ? <div className="text-xs text-gray-600">{s.address}</div> : null}
          <div className="text-xs">
            {s.rating != null ? `⭐ ${s.rating}` : ""}
            {s.open_now != null ? (s.open_now ? " · Open now" : " · Closed") : ""}
            {s.phone ? ` · ${s.phone}` : ""}
          </div>
          {s.maps_url ? (
            <div className="mt-1">
              <a target="_blank" className="inline-block rounded bg-green-100 px-2 py-0.5 text-xs text-green-700 hover:bg-green-200" href={s.maps_url}>
                Open in Google Maps
              </a>
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}
