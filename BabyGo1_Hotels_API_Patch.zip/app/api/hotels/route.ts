import { NextResponse } from "next/server";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const lat = searchParams.get("lat");
    const lng = searchParams.get("lng");
    const radius = searchParams.get("radius") || "5000"; // meters
    if (!lat || !lng) {
      return NextResponse.json({ error: "lat and lng required" }, { status: 400 });
    }

    const key = process.env.GOOGLE_MAPS_API_KEY || process.env.GOOGLE_PLACES_KEY;
    if (!key) {
      return NextResponse.json({ error: "Missing GOOGLE_MAPS_API_KEY in .env.local" }, { status: 500 });
    }

    const url = new URL("https://maps.googleapis.com/maps/api/place/nearbysearch/json");
    url.searchParams.set("location", `${lat},${lng}`);
    url.searchParams.set("radius", radius);
    url.searchParams.set("type", "lodging");
    url.searchParams.set("keyword", "family baby crib cot kids");
    url.searchParams.set("key", key as string);

    const res = await fetch(url.toString(), { next: { revalidate: 0 } });
    const data = await res.json();

    if (!res.ok) {
      return NextResponse.json({ error: data?.error_message || "Upstream error" }, { status: res.status });
    }

    const items = (data.results || []).map((r: any) => ({
      name: r.name,
      rating: r.rating ?? null,
      ratings: r.user_ratings_total ?? null,
      priceLevel: r.price_level ?? null,
      address: r.vicinity || r.formatted_address || "",
      place_id: r.place_id,
      location: r.geometry?.location || null,
      maps_url: r.place_id ? `https://www.google.com/maps/place/?q=place_id:${r.place_id}` : null,
      hints: { likelyCribs: /family|baby|kids|child|crib|cot/i.test(`${r.name} ${r.types?.join(" ") || ""}`) }
    }));

    return NextResponse.json(items);
  } catch (e:any) {
    return NextResponse.json({ error: e?.message || "Unknown error" }, { status: 500 });
  }
}
