// components/HotelsTab.tsx
"use client";
import React from "react";
import { useSearchParams } from "next/navigation";
import HotelsCard from "@/components/HotelsCard";

type Item = {
  name: string;
  address?: string;
  rating?: number | null;
  ratings?: number | null;
  priceLevel?: number | null;
  maps_url?: string | null;
  grade?: "A"|"B"|"C"|"D";
  score?: number | null;
  hints?: { likelyCribs?: boolean };
};

export default function HotelsTab(){
  const sp = useSearchParams();
  const lat = sp.get("lat") ? Number(sp.get("lat")) : undefined;
  const lng = sp.get("lng") ? Number(sp.get("lng")) : undefined;
  const minRating = sp.get("minRating") || "";
  const maxPrice  = sp.get("maxPrice") || "";
  const cribOnly  = sp.get("cribOnly") === "true";
  const q         = sp.get("q") || "";
  const age       = sp.get("childAge") || sp.get("age") || "7-12m";
  const radius    = sp.get("radius") || "5000";

  const [loading, setLoading] = React.useState(false);
  const [items, setItems]     = React.useState<Item[]>([]);
  const [err, setErr]         = React.useState<string|null>(null);

  React.useEffect(()=>{
    async function load(){
      if (lat == null || lng == null) { setItems([]); return; }
      setLoading(true); setErr(null);
      try{
        const p = new URLSearchParams({ lat:String(lat), lng:String(lng), radius, age });
        if (minRating) p.set("minRating", minRating);
        if (maxPrice)  p.set("maxPrice",  maxPrice);
        if (cribOnly)  p.set("cribOnly",  "true");
        if (q)         p.set("q",         q);
        const r = await fetch(`/api/hotels?${p.toString()}`, { cache: "no-store" });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data = await r.json();
        setItems(data.items || []);
      }catch(e:any){
        setErr(e?.message || "Failed to load hotels");
      }finally{
        setLoading(false);
      }
    }
    load();
  }, [lat, lng, minRating, maxPrice, cribOnly, q, radius, age]);

  if (lat == null || lng == null) return <p className="text-sm text-slate-600">Select a destination (or use a supported city) to see hotels.</p>;
  if (loading) return <p className="text-sm text-slate-600">Loading hotels…</p>;
  if (err) return <p className="text-sm text-red-600">Error: {err}</p>;
  if (!items.length) return <p className="text-sm text-slate-600">No hotels found for this destination yet.</p>;

  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((h, i) => (
        <HotelsCard
          key={`${h.maps_url || h.name}-${i}`}
          name={h.name}
          address={h.address}
          rating={h.rating ?? null}
          ratings={h.ratings ?? null}
          priceLevel={h.priceLevel ?? null}
          maps_url={h.maps_url || null}
          grade={h.grade}
          score={typeof h.score === "number" ? h.score : null}
          badges={[
            ...(h.hints?.likelyCribs ? ["Cribs"] : []),
            ...(q ? [`Match: ${q}`] : []),
          ]}
        />
      ))}
    </div>
  );
}
