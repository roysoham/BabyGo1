// app/(site)/results/page.tsx
import ResultsView from "@/components/ResultsView";

export const dynamic = "force-dynamic";

export default function Page({ searchParams }: { searchParams: { [k: string]: string | string[] | undefined } }) {
  return <ResultsView searchParams={searchParams} />;
}
