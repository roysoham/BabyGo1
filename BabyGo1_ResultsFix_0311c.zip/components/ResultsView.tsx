// components/ResultsView.tsx
import Tabs from "@/components/Tabs";
import ResultsHeader from "@/components/ResultsHeader";
import HotelsList from "@/components/HotelsList";
import SafetyList from "@/components/SafetyList";
import PackingList from "@/components/PackingList";
import ProductsList from "@/components/ProductsList";
import hotelsLocal from "@/data/hotels.json";
import safetyData from "@/data/safety_contacts.json";
import packingTemplates from "@/data/packing_templates.json";
import productsData from "@/data/products.json";

// ---- Robust import resolver for BCS -----------------------------------------
import * as bcsEngineNS from "@/lib/bcsEngine";

function resolveComputeBCS(): any {
  const ns: any = bcsEngineNS as any;
  if (typeof ns.computeBCS === "function") return ns.computeBCS;
  if (typeof ns.default === "function") return ns.default;
  if (ns.default && typeof ns.default.computeBCS === "function") return ns.default.computeBCS;
  // last resort: still render UI
  return (_args: any) => ({
    total: 70,
    pace: "Moderate",
    napBlocks: 2,
    breakdown: [
      { label: "Healthcare", score: 70 },
      { label: "Hygiene", score: 70 },
      { label: "Accessibility", score: 80 },
      { label: "Low-stimulation", score: 60 },
    ],
  });
}
const computeBCS = resolveComputeBCS();

// ---- Helpers ----------------------------------------------------------------
type SP = { [k: string]: string | string[] | undefined };
function norm(s?: string) { return (s ?? "").toLowerCase().trim(); }

const CITY_COORDS: Array<{ match: string; lat: number; lng: number }> = [
  { match: "paris", lat: 48.8566, lng: 2.3522 },
  { match: "tokyo", lat: 35.6762, lng: 139.6503 },
  { match: "rome", lat: 41.9028, lng: 12.4964 },
  { match: "london", lat: 51.5072, lng: -0.1276 },
  { match: "new york", lat: 40.7128, lng: -74.0060 },
  { match: "singapore", lat: 1.3521, lng: 103.8198 },
  { match: "dubai", lat: 25.2048, lng: 55.2708 },
  { match: "bangkok", lat: 13.7563, lng: 100.5018 },
  { match: "sydney", lat: -33.8688, lng: 151.2093 },
  { match: "barcelona", lat: 41.3874, lng: 2.1686 },
];

function resolveCoordsFromCities(freeText?: string): { lat: number; lng: number } | null {
  const key = norm(freeText);
  const hit = CITY_COORDS.find(c => key.includes(c.match));
  return hit ? { lat: hit.lat, lng: hit.lng } : null;
}

async function fetchDetails(placeId: string){
  try{
    const base = process.env.NEXT_PUBLIC_BASE_URL || "";
    const r = await fetch(`${base}/api/places/details?placeId=${encodeURIComponent(placeId)}`, { cache: "no-store" });
    if (!r.ok) return null;
    return await r.json();
  }catch{
    return null;
  }
}

async function fetchHotels(lat:number, lng:number){
  try{
    const base = process.env.NEXT_PUBLIC_BASE_URL || "";
    const r = await fetch(`${base}/api/hotels?lat=${lat}&lng=${lng}&radius=3500&limit=20`, { cache: "no-store" });
    if (!r.ok) return [];
    const data = await r.json();
    return Array.isArray(data?.items) ? data.items : data;
  }catch{
    return [];
  }
}

// ---- Main component ----------------------------------------------------------
export default async function ResultsView({ searchParams }: { searchParams: SP }){
  const q: Record<string, string> = Object.fromEntries(
    Object.entries(searchParams || {}).map(([k,v]) => [k, Array.isArray(v) ? v[0] ?? "" : v ?? ""])
  );

  const fromText = q.from || "";
  const toText = q.to || "";
  const fromId = q.fromId || "";
  const toId = q.toId || "";
  const depart = q.depart || "";
  const ret = q.ret || "";
  const age = q.childAge || "7-12m";
  const directOnly = (q.directOnly || "true") === "true";
  const travellers = parseInt(q.travellers || "2");

  let toDetails: any = null;
  if (toId) toDetails = await fetchDetails(toId as string);

  let lat: number | null = null;
  let lng: number | null = null;
  if (toDetails?.result?.geometry?.location) {
    lat = toDetails.result.geometry.location.lat ?? null;
    lng = toDetails.result.geometry.location.lng ?? null;
  } else {
    const approx = resolveCoordsFromCities(toText);
    if (approx) { lat = approx.lat; lng = approx.lng; }
  }

  const country =
    toDetails?.result?.address_components?.find((c:any)=>c.types?.includes("country"))?.long_name
    || "";

  const bcs = computeBCS({ age: String(age), directOnly, country });

  // Hotels
  let hotels: any[] = [];
  let apiTried = false;
  if (lat && lng) {
    hotels = await fetchHotels(lat, lng);
    apiTried = true;
  }
  if (!hotels?.length) {
    hotels = (hotelsLocal as any[]).filter(h => toText && norm(h.city) === norm(toText));
  }

  const safety = (safetyData as any[]).filter(s => toText && norm(s.city) === norm(toText));

  const tabs = [
    { id: "itinerary", label: "Itinerary" },
    { id: "hotels", label: "Hotels" },
    { id: "safety", label: "Safety" },
    { id: "packing", label: "Packing" },
    { id: "products", label: "Products" },
  ];

  return (
    <section className="mx-auto max-w-6xl space-y-4 p-4">
      <ResultsHeader
        title={`Results — ${toText || "Destination"}`}
        subtitle={`From ${fromText || "Origin"} · Depart ${depart || "—"} · Return ${ret || "—"} · Travellers ${travellers} · Age ${age} · ${directOnly ? "Direct only" : "Any flights"}`}
        coords={lat && lng ? { lat, lng } : null}
      />
      <Tabs tabs={tabs}>
        {/* Itinerary */}
        <div>
          <p className="text-sm">BCS: <b>{bcs.total}</b> · Pace: <b>{bcs.pace}</b> · Nap blocks/day: <b>{bcs.napBlocks}</b></p>
          <ul className="mt-2 list-disc pl-6 text-sm">
            {bcs.breakdown.map((b: any) => (<li key={b.label}>{b.label} {b.score}/100</li>))}
          </ul>
          <div className="mt-3 grid gap-3 md:grid-cols-3">
            <div className="rounded-xl border p-3"><h3 className="font-medium">Day 1</h3><p>Stroller‑friendly activity</p><p>Pace: {bcs.pace}</p></div>
            <div className="rounded-xl border p-3"><h3 className="font-medium">Day 2</h3><p>Low‑stim museum / park</p><p>Pace: {bcs.pace}</p></div>
            <div className="rounded-xl border p-3"><h3 className="font-medium">Day 3</h3><p>Short transit, playground</p><p>Pace: {bcs.pace}</p></div>
          </div>
        </div>
        {/* Hotels */}
        <div className="space-y-3">
          <div className="flex gap-2 text-xs text-gray-600">
            {!hotels?.length ? <span className="rounded-full bg-gray-100 px-2 py-1">no results</span> : null}
            <span className="rounded-full bg-gray-100 px-2 py-1">
              coords source: {lat && lng ? (toId ? "placeId" : "city-approx") : "none"}
            </span>
            <span className="rounded-full bg-gray-100 px-2 py-1">
              api tried: {String(apiTried)}
            </span>
          </div>
          <HotelsList items={hotels as any} />
        </div>
        {/* Safety */}
        <div>
          <SafetyList items={safety as any} />
        </div>
        {/* Packing */}
        <div>
          <PackingList age={String(age)} templates={packingTemplates as any} />
        </div>
        {/* Products */}
        <div>
          <ProductsList items={productsData as any} />
        </div>
      </Tabs>
    </section>
  );
}
