"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function SearchForm() {
  const router = useRouter();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [depart, setDepart] = useState("");
  const [ret, setRet] = useState("");
  const [travellers, setTravellers] = useState(2);
  const [childAge, setChildAge] = useState("7-12m");
  const [directOnly, setDirectOnly] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    if (!from || !to || !depart) { setErr("Please fill From, To and Depart date."); return; }
    if (ret && ret < depart) { setErr("Return date cannot be before Depart date."); return; }
    const q = new URLSearchParams({
      from, to, depart, ret,
      travellers: String(travellers),
      childAge, directOnly: String(directOnly),
    });
    router.push(`/results?${q.toString()}`);
  }

  return (
    <form onSubmit={onSubmit} className="mx-auto max-w-4xl rounded-2xl border bg-white p-4 shadow">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-6">
        <input className="rounded-lg border px-3 py-2" placeholder="From"
               value={from} onChange={(e)=>setFrom(e.target.value)} />
        <input className="rounded-lg border px-3 py-2" placeholder="To"
               value={to} onChange={(e)=>setTo(e.target.value)} />
        <input type="date" className="rounded-lg border px-3 py-2"
               value={depart} onChange={(e)=>setDepart(e.target.value)} />
        <input type="date" className="rounded-lg border px-3 py-2"
               value={ret} onChange={(e)=>setRet(e.target.value)} />
        <select className="rounded-lg border px-3 py-2" value={childAge} onChange={(e)=>setChildAge(e.target.value)}>
          <option value="0-3m">0-3m</option>
          <option value="4-6m">4-6m</option>
          <option value="7-12m">7-12m</option>
          <option value="1-3y">1-3y</option>
          <option value="3-5y">3-5y</option>
        </select>
        <input type="number" min={1} max={8} className="rounded-lg border px-3 py-2"
               value={travellers} onChange={(e)=>setTravellers(parseInt(e.target.value||"1"))} />
      </div>
      <label className="mt-2 flex items-center gap-2 text-sm">
        <input type="checkbox" checked={directOnly} onChange={(e)=>setDirectOnly(e.target.checked)} /> Direct only
      </label>
      <div className="mt-3 flex items-center justify-end gap-3">
        <button type="submit" className="rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-500 px-5 py-2 font-semibold text-white shadow">Search</button>
      </div>
      {err && <p className="mt-2 text-sm text-red-600">{err}</p>}
    </form>
  );
}
