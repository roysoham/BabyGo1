# Data schemas for BCS, Hotels, Packing, Products
