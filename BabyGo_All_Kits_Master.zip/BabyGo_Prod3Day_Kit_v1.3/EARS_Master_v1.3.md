# EARS v1.3 full framework
