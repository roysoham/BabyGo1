// SN: BABYGOV1-20250901

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html><body>{children}</body></html>)
}
