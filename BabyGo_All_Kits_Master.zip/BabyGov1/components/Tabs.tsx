// SN: BABYGOV1-20250901
export default function Tabs(){return <div>Tabs</div>}