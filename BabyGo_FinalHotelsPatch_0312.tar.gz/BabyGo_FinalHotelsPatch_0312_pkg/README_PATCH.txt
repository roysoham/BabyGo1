BabyGo Final Hotels Patch 0312 - packaged as tar.gz
